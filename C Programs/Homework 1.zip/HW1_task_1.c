/*
* Write a program that outputs "CSE" in letters
* Written by Harris Nghiem
* January 27th, 2015
* CSE 1320 - Intermediate Programming
*/

#include <stdio.h>

char main(void)
{
    #define STR_C "CCCCCCCCCCCCC"

    //using strings
    printf("%-16s", STR_C); //16 for the 13 C's and the three spaces after

    //using %c or characters as a formatter
    printf("%c%c%c%c%c%c%c%c%c%c%c%c%c\t",'S','S','S','S','S','S','S','S','S','S','S','S','S');
    printf("%c%c%c%c%c%c%c%c%c%c%c%c%c \n",'E','E','E','E','E','E','E','E','E','E','E','E','E');

    //using %s or strings as a formatter
    printf("%-16s%-10s%-6s%-15s\n", "CC", "SSS", "SSS", "EE");
    printf("%2s%17s%15s\n", "CC" ,"SSS" ,"EE");
    printf("%-16.2s%-16.13s%-16.16s\n", "CCXXXXXXXXXXXXX", "SSSSSSSSSSSSSXXX", "EEEEEEEEEEEEE");
    printf("%2s%27s%5s\n", "CC", "SSS", "EE");
    printf("%-15s%4s%10s%5.2s\n", "CC", "SSS", "SSS", "EEXXX");

    //just a normal print with no parameters to the %s
    printf("%s", "CCCCCCCCCCCCC   SSSSSSSSSSSSS   EEEEEEEEEEEEE");
    return 0;
}
