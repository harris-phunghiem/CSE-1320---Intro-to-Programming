/*
* Write a program that takes an input from user, and prints them
* Written by Harris Nghiem
* January 27th, 2015
* CSE 1320 - Intermediate Programming
*/

#include <stdio.h>

int main()
{

    //Variable declarations
    char sUser_Name [80];
    int nFirst_Score;
    int nSecond_Score;
    float nAvg_Score;

    //prompt user for name
    printf("Please enter your first name: ");
    scanf("%79s", &sUser_Name);
    printf("Hello %s!\n", sUser_Name);

    //prompt for first test score
    printf("%s, what was the score of your first test? ", sUser_Name);
    scanf("%d", &nFirst_Score);

    //prompt for the second test score
    printf("What was the score of your second test? ");
    scanf("%d", &nSecond_Score);
    printf("Thank you! Your first test score was %d%%, and your second test score was %d%%\n\n", nFirst_Score, nSecond_Score);

    //calculate Average score from Two tests
    nAvg_Score = (nFirst_Score+nSecond_Score)/2.0;

    printf("Your average of the tests are %3.2f%%\n\n\n", nAvg_Score);

    //gives letter grade

    if (nAvg_Score >= 69.4)
    {
        if (nAvg_Score >=79.4)
        {
            if (nAvg_Score >= 89.4)
            {
                printf("Congratulations, you have an 'A' in the class!");
            }
            else
            {
                printf("You have a 'B' in the class");
            }
        }
        else
        {
            printf("You have a 'C' in the class");
        }
    }

    if (nAvg_Score < 69.4)
    {
        printf("You should talk to your teacher");
    }



    return 0;
}
