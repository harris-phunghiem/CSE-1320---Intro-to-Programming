/*Made by Harris
Homework 7 - Library Manager*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <conio.h>
#include <time.h>


//Date Structure
typedef struct
{
    int nDay;
    int nMonth;
    int nYear;
}Due;


//for keeping track of due dates
Due due[50],current[50];


//Define structure of book
typedef struct
{
    char szISBN[100];
    char szBook_Name[100];
    char szType[100];
    char szPublisher[100];
    int nPages;
    float fPrice;
    int nYear_Published; //MMYY
    int nAvailability; //0 for no, 1 for yes
    char szCustomer[100]; //Customer that checked out book
    int nDays_Left;

}Book;

//Array of structures. Max of 50 books
Book book[50];

//Shows all Available book, and returns the book number
int Book_Availability(int nBook_Num)
{

    int i;

    //a value of "a" means the book is available
    for(i=0;i<49;i++)
    {
        if(!(strcmp(book[i].szISBN, "a")))
        {
            nBook_Num = i;
            break;
        }
        else
            continue;
    }
    return nBook_Num;

}

//Shows every book in the library database
void Show_All()
{
    system("cls");
    int i,b=0;
    for(i=0;i<=49;i++)
    {
        if( book[i].nAvailability == 1 || book[i].nAvailability == 0 )
        {
            printf("Book Name: %-30s   Book # %d\n\n", book[i].szBook_Name, i+1);
            printf("%-14s%-10s%-20s%-30s\n", "ISBN", "Type", "Publisher", "Customer");
            printf("%-14s%-10s%-20s%-30s\n\n", book[i].szISBN, book[i].szType, book[i].szPublisher, book[i].szCustomer);
            printf("%-10s%8s%18s%16s%20s\n", "Pages", "Cost","Availability", "Due Date", "Days Left");
            printf("%-14d$%5.2f", book[i].nPages, book[i].fPrice);
            if(book[i].nAvailability == 1)
                printf("\tYES\t\t");
            if(book[i].nAvailability == 0)
                printf("\tNO\t\t");
            printf("%6d/%2d/%4d%11d\t \n\n\n",due[i].nMonth,due[i].nDay,due[i].nYear,book[i].nDays_Left);
            printf("---------------------------------------------------------------------\n");
            b=1;

        }
    }
    if(b == 0)
        printf("Sorry! There are no books in the system\n\n\n");

}

//Function that shows all books that are checked in
void Show_All_Checked_In()
{
    system("cls");
    int i,b=0;
    for(i=0;i<=49;i++)
    {
        if( book[i].nAvailability == 1)
        {
            printf("Book Name: %-30s   Book # %d\n\n", book[i].szBook_Name, i+1);
            printf("%-14s%-10s%-20s%-30s\n", "ISBN", "Type", "Publisher", "Customer");
            printf("%-14s%-10s%-20s%-30s\n\n", book[i].szISBN, book[i].szType, book[i].szPublisher, book[i].szCustomer);
            printf("%-10s%8s%18s%16s\n", "Pages", "Cost","Availability", "Due Date");
            printf("%-14d$%5.2f", book[i].nPages, book[i].fPrice);
            if(book[i].nAvailability == 1)
                printf("\tYES\t\t");
            if(book[i].nAvailability == 0)
                printf("\tNO\t\t");
            printf("%6d/%2d/%4d\t \n\n\n",due[i].nMonth,due[i].nDay,due[i].nYear,book[i].nAvailability,i+1);
            printf("---------------------------------------------------------------------\n");
            b=1;

        }
    }
    if(b == 0)
        printf("There are no books that are checked in\n\n\n");

}

//Function to remove a book. Sets the availability to -1, and copies "a" to the ISBN like the defaults
void Remove_Book(int a)
{
    strcpy(book[a-1].szISBN, "a");
    book[a-1].nAvailability = -1;
    book[a-1].nDays_Left = NULL;


    //anytime a book is removed, we need to update our automatic save file
    FILE * file= fopen("libData", "wb");
    if (file != NULL)
    {
        fwrite(book, sizeof(book[0]), 50, file);
        fclose(file);
    }

    FILE * file1= fopen("DueDates", "wb");
    if (file1 != NULL)
    {
        fwrite(due, sizeof(due[0]), 50, file1);
        fclose(file1);
    }
}

//Shows all available books that are available to be removed
int Show_Removable_Books(int z)
{
    system("cls");
    int i,b = 1;
    for(i=0;i<=49;i++)
    {
        if(book[i].nAvailability == 1 || book[i].nAvailability == 0)
        {
            printf("Book #%d - %-35s is available to be removed.\n",i+1,book[i].szBook_Name);
            b = 0;
        }
    }
    if(b==1)
    {
        printf("Sorry! There are no books in the system.\n\n\n");
        return 2;
    }
    printf("\n\n\n");
}

//Function to check out a book, and gets input date for current and due
void Check_Out(int a)
{

    //create a time structure
    time_t t = time(NULL);
    struct tm tm = *localtime(&t);


    getchar();
    char Input[50] = "";
    char Space;
    book[a-1].nAvailability = 0;
    printf("Who rented the book?: ");
    if (fgets(Input, sizeof Input, stdin) != NULL)
    {
        int len = strlen(Input);
        if (len > 0 && Input[len-1] == '\n') {
            Input[--len] = '\0';
        }
    }

    strcpy(book[a-1].szCustomer,Input);


    printf("Book was checked out on: %d-%d-%d at %d:%d:%d\n", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec);
    (current[a-1].nMonth) = tm.tm_mon + 1;
    (current[a-1].nYear) = tm.tm_year + 1900;
    (current[a-1].nDay) = tm.tm_mday;



    while (1)
    {

        printf("\nWhat year is it due? ");
        scanf("%d%c",&due[a-1].nYear,&Space);
        if (due[a-1].nYear < current[a-1].nYear)
        {
            if (due[a-1].nYear < 2014 || due[a-1].nYear > 9999)
            {
                printf("Sorry, year is out of bounds.\n");
                continue;
            }
            else
            {
                printf("Invalid year, please try again\n");
                continue;
            }
        }
        break;

    }
    while(1)
    {
        printf("Due month (MM) ");
        scanf("%d%c",&due[a-1].nMonth,&Space);
        if(due[a-1].nMonth < current[a-1].nMonth && due[a-1].nYear == current[a-1].nYear)
        {
            if (due[a-1].nMonth < 1 || due[a-1].nMonth >12)
            {
                printf("Invalid month.  Try again.\n");
                continue;
            }
            else
            {
                printf("Invalid month, please try again\n");
                continue;
            }
        }
        break;
    }

    while (1)
    {
        printf("Due day (DD) ");
        scanf("%d%c",&due[a-1].nDay,&Space);

        if(due[a-1].nDay < current[a-1].nDay && due[a-1].nMonth == current[a-1].nMonth && due[a-1].nYear == current[a-1].nYear)
        {
            if (dayLegalityCheck(due[a-1].nMonth,due[a-1].nDay,due[a-1].nYear) == 0)
            {
                printf("This day cannot exist on this month.");
                continue;
            }
            else
            {
                printf("Invalid day, please try again\n");
                continue;
            }
        }
        break;
    }


    book[a-1].nDays_Left = Days_Left(due[a-1].nMonth,due[a-1].nDay,due[a-1].nYear,current[a-1].nMonth,current[a-1].nDay,current[a-1].nYear);

    //update save data
    FILE * file= fopen("libData", "wb");
    if (file != NULL)
    {
        fwrite(book, sizeof(book[0]), 50, file);
        fclose(file);
    }

    FILE * file1= fopen("DueDates", "wb");
    if (file1 != NULL)
    {
        fwrite(due, sizeof(due[0]), 50, file1);
        fclose(file1);
    }
    system("cls");

}

//Check in a book by setting the availability to 1
void Check_In(int a)
{
    book[a-1].nAvailability = 1;
    strcpy(book[a-1].szCustomer, "");
    due[a-1].nDay = NULL;
    due[a-1].nMonth = NULL;
    due[a-1].nYear = NULL;
    book[a-1].nDays_Left = NULL;

    //update save data
    FILE * file= fopen("libData", "wb");
    if (file != NULL)
    {
        fwrite(book, sizeof(book[0]), 50, file);
        fclose(file);
    }

    FILE * file1= fopen("DueDates", "wb");
    if (file1 != NULL)
    {
        fwrite(due, sizeof(due[0]), 50, file1);
        fclose(file1);
    }
    system("cls");
}

//Shows all books that have an availability of 0
int Show_Checkedout_Books(int z)
{
    system("cls");
    int i,b=0;
    for(i=0;i<=49;i++)
    {
        if( book[i].nAvailability == 0 )
        {
            printf("Book Name: %-30s   Book # %d\n\n", book[i].szBook_Name, i+1);
            printf("%-14s%-10s%-20s%-30s\n", "ISBN", "Type", "Publisher", "Customer");
            printf("%-14s%-10s%-20s%-30s\n\n", book[i].szISBN, book[i].szType, book[i].szPublisher, book[i].szCustomer);
            printf("%-10s%8s%18s%16s%20s\n", "Pages", "Cost","Availability", "Due Date", "Days Left");
            printf("%-14d$%5.2f", book[i].nPages, book[i].fPrice);
            if(book[i].nAvailability == 1)
                printf("\tYES\t\t");
            if(book[i].nAvailability == 0)
                printf("\tNO\t\t");
            printf("%6d/%2d/%4d%11d\t \n\n\n",due[i].nMonth,due[i].nDay,due[i].nYear,book[i].nDays_Left);
            printf("---------------------------------------------------------------------\n");
            b=1;
        }
    }
    if(b == 0)
    {
        printf("There are no books that have been checked out\n\n\n");
        return 2;
    }
}

//Shows books that have availability set to 1
int Show_Checkedin_Books(int z)
{
    system("cls");
    int i,b=1;
    for(i=0;i<=49;i++)
    {
        if(book[i].nAvailability == 1)
        {
            printf("Book#[%d]\t%s\t is available.\n",i+1,book[i].szBook_Name);
            b=0;
        }
    }
    if(b==1)
    {
        printf("No books are available to be checked out.\n\n\n");
        return 2;
    }
    printf("\n\n\n");
}



int main(void)


{
    //let user know today's date and time
    time_t t = time(NULL);
    struct tm tm = *localtime(&t);

    printf("It is currently: %d-%d-%d \n",tm.tm_mon + 1, tm.tm_mday, tm.tm_year + 1900);
    //Initialize all book ISBNS to null to show availability and set all book availability to -1
    int flag = 0;
    int b=0;
    for(b=0; b<=49; b++)
    {
        strcpy(book[b].szISBN, "a");
        book[b].nAvailability = -1;
    }

    //force load of file, if it exists
        FILE * file= fopen("libData", "rb");
        if (file != NULL)
        {
            flag = 1;
            fread(&book, sizeof(book[0]), 50, file);
            fclose(file);
        }
        FILE * file1= fopen("DueDates", "rb");
        if (file1 != NULL)
        {
            flag = 1;
            fread(&due, sizeof(due[0]), 50, file1);
            fclose(file1);
        }


    //Ask which book the user would like to input/edit
    int nBook_Selection=0;

    do
    {



        //Shows menu to user
        char *rgnMenu[500] = {
            "1. Add a new book",
            "2. Remove a book",
            "3. Check out a book",
            "4. Check in a book",
            "5. Display all available book details",
            "6. Display all checked-out books",
            "7. Display all checked-in books",
            "8. Exit program"};

        //Display the menu to the user
        int i;
        for(i=0;i<8;i++)
        {
            printf("%s\n", *(rgnMenu+i));
        }

        //Checks to see if the book is available
        nBook_Selection = Book_Availability(nBook_Selection);


        //Asks for user input from menu
        int nMenu_Selection =0;
        char szUser_Input[100] = "";
        printf("\n\nPlease enter in a selection from the menu: ");
        scanf("%d", &nMenu_Selection);
        switch(nMenu_Selection)
        {
            case 1:
            {
                getchar();


                printf("What is the book ISBN? ");
                if (fgets(szUser_Input, sizeof szUser_Input, stdin) != NULL)
                {
                    int len = strlen(szUser_Input);
                    if (len > 0 && szUser_Input[len-1] == '\n') {
                        szUser_Input[--len] = '\0';
                    }
                }
                strcpy(book[nBook_Selection].szISBN,szUser_Input);


                printf("What is the book name? ");
                if (fgets(szUser_Input, sizeof szUser_Input, stdin) != NULL)
                {
                    int len = strlen(szUser_Input);
                    if (len > 0 && szUser_Input[len-1] == '\n') {
                        szUser_Input[--len] = '\0';
                    }
                }
                strcpy(book[nBook_Selection].szBook_Name,szUser_Input);

                printf("What is the book type? ");
                if (fgets(szUser_Input, sizeof szUser_Input, stdin) != NULL)
                {
                    int len = strlen(szUser_Input);
                    if (len > 0 && szUser_Input[len-1] == '\n') {
                        szUser_Input[--len] = '\0';
                    }
                }
                strcpy(book[nBook_Selection].szType,szUser_Input);

                printf("Who is the book publisher? ");
                if (fgets(szUser_Input, sizeof szUser_Input, stdin) != NULL)
                {
                    int len = strlen(szUser_Input);
                    if (len > 0 && szUser_Input[len-1] == '\n') {
                        szUser_Input[--len] = '\0';
                    }
                }
                strcpy(book[nBook_Selection].szPublisher,szUser_Input);

                printf("How many pages are in the book? ");
                scanf("%d", &book[nBook_Selection].nPages);

                printf("How much does the book cost? ");
                scanf("%f", &book[nBook_Selection].fPrice);

                book[nBook_Selection].nAvailability = 1;
                system("cls");

                FILE * file= fopen("libData", "wb");
                if (file != NULL)
                {
                    fwrite(book, sizeof(book[0]), 50, file);
                    fclose(file);
                }

                FILE * file1= fopen("DueDates", "wb");
                if (file1 != NULL)
                {
                    fwrite(due, sizeof(due[0]), 50, file1);
                    fclose(file1);
                }

                printf("Congrats! You've successfully entered a book.\n\n\n");
                break;
            }
            case 2:
            {
                int x;
                x = Show_Removable_Books(x);
                    if(x==2)
                        break;
                printf("What book # would you like to remove?");
                scanf("%d", &nBook_Selection);
                Remove_Book(nBook_Selection);
                printf("You have successfully removed Book %d", nBook_Selection);
                system("cls");
                break;
            }
            case 3:
            {
                int y;
                y = Show_Checkedin_Books(y);
                    if(y==2)
                        break;
                printf("What book would you like to check out?");
                scanf("%d", &nBook_Selection);
                Check_Out(nBook_Selection);
                break;
            }
            case 4:
            {
                int z;
                z = Show_Checkedout_Books(z);
                    if(z==2)
                        break;
                printf("What book would you like to check in?");
                scanf("%d", &nBook_Selection);
                Check_In(nBook_Selection);
                break;
            }
            case 5:
            {
                Show_All();
                break;
            }
            case 6:
            {
                int e;
                e = Show_Checkedout_Books(e);
                break;
            }
            case 7:
            {
               Show_All_Checked_In();
               break;
            }
            case 8:
                exit(0);
        }
    }while(1);
    return 0;
}

//Function to check if dates inputed by user are correct, inclusive of leap year
int dayLegalityCheck(int duemonth, int dueday, int dueyear)
{


    //takes care of months that are supposed to have 31 days
    if ( (duemonth == 1 || duemonth ==  3 || duemonth ==  5 || duemonth ==  7 || duemonth ==  8||  duemonth ==  10 || duemonth ==  12) && ( dueday > 0 && dueday < 32) )
        return 1;

    //takes care of months that are supposed to have 30 days
    else if ( (duemonth == 4 || duemonth ==  6 || duemonth ==  9 || duemonth ==  11) && ( dueday > 0 && dueday < 31) )
        return 1;

    //takes care of February
    else if ( (duemonth == 2))
    {
        //leap year feb 29
        if (dueday == 29 && dueyear%4 == 0)
            return 1;

        //feb 29 on a non leap year
        else if (dueday == 29 && dueyear%4 !=0)
            return 0;

        //any other legal day in february
        else if (dueday > 0 && dueday < 29)
            return 1;

        //all other results (less than 1 or greater than 29)
        else
            return 0;
    }

    //all other results are automatically illegal
    else
        return 0;
}

int Convert_To_Days(int day, int month)
{
    //array is based on corresponding month's number of days
    int rgnMonths[]={0,31,28,31,30,31,30,31,31,30,31,30,31};
    int nDays=0;
    int i;

    int Month = month;

    for(i=0;i<Month;i++)
        nDays += rgnMonths[i];
    nDays += day;

    return nDays;
}

//Function to check how many days are left
int Days_Left(int duemonth, int dueday, int dueyear, int CurrentMonth, int CurrentDay, int CurrentYear)
{
    int nDays;
    int Currentindays;
    int Dueindays;

    if(dueyear == CurrentYear){
        Currentindays = Convert_To_Days(CurrentDay,CurrentMonth);
        Dueindays = Convert_To_Days(dueday,duemonth);
        nDays = Dueindays - Currentindays;
        //printf("%d in first loop\n", nDays);
        }
    if ((dueyear - 1) == CurrentYear)
        {
        Currentindays = Convert_To_Days(CurrentDay,CurrentMonth);
        Dueindays = 365+ Convert_To_Days(dueday,duemonth);
        nDays = Dueindays - Currentindays;
        //printf("%d in second loop\n", nDays);
        }


    return nDays;
}
