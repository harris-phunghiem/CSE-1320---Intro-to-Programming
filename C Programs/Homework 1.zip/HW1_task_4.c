/*Print Pi in different formats, but as a constant
*By Harris Nghiem
*/

#include <stdio.h>
#define M_PI 3.14159265359

int main()
{
    printf("The number PI can be represented as\n%.6f\n%3.6e\n", M_PI, M_PI);
    printf("%010f",M_PI);
    return 0;
}

