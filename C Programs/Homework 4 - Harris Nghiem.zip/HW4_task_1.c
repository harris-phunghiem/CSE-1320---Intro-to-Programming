/*Made by Harris Nghiem
CSE 1320
Homework 4 - Task 1*/

#include <stdio.h>
#include <string.h>

//repitions functions
void no_repetitions(char *inputString);

//
int main()
{

    //string array (should be big enough for HW purposes)
    char inputString[5000];

    printf("Please type in a string: ");
    gets(inputString);


    //parameter is a string
    no_repetitions(inputString);

    //conventional return
    return 0;


}


void no_repetitions(char *inputString)
{

    //need to know how big the string is
    int stringSize;
    stringSize = strlen(inputString);

    //dupArray will hold the output array
    int dupCheckArray[stringSize];

    int i = 0;  //input string iterator
    int j = 0;  //dupcheck string iterator
    int b = 0;

    int currentMax = 0; //how far the dupcheck array has been filled



    //dupCheckArray needs to be initialized with an obscure character that
    //no one will ever type into the input.  '\a' is the "bell sound" and is
    //a great candidate.
    for (b=0; b < stringSize; b++)
    {
        dupCheckArray[b] = '\a';
    }

    //goes through the string letter by letter
    for (i=0;i<stringSize;i++)
    {
        if (!stringSize)
        {
            break;
        }
        //goes through the dupArray letter by letter
        for (j=0;j<stringSize;j++)
        {
            if (dupCheckArray[j]=='\a')
            {
                dupCheckArray[j]=inputString[i];
                break;
            }
            if (dupCheckArray[j]==inputString[i])
            {
                break;
            }
        }

    }


    //print the result
    for (i=0;i<1000;i++)
    {
        if (dupCheckArray[i] == '\a')
        {
            break;
        }
        printf("%c",dupCheckArray[i]);
    }

}
