/*Made by Harris Nghiem
CSE 1320
Homework 4 - Task 1*/

#include <time.h>
#include <stdlib.h>
#include <stdio.h>

void main()
{

    //2d array for random numbers
    int numArray[10][100];

    //1d array for duplicates
    int dupArray[100];

    //seed for random number; based on current time
    srand(time(NULL));

    //iterators for 2d index
    int i;
    int j;

    //dupIndex iterator (d stands for "duplicates")
    int d;

    //current max in duplicate array
    int dupIndexMax=0;

    //element; for readability
    int myNum;

    //reset array to all -1's
    for (i=0; i<10; i++)
    {
        for (j=0;j<100;j++)
        {
            dupArray[i]=-1;
        }
    }

    //for each row in the 2d array
    for (i=0; i<10; i++)
    {


        printf("Element %d duplicates: ",i);

        //for each "column" in the 2d array
        for (j=0;j<100;j++)
        {
            myNum = numArray[i][j]=(rand()%501);
            //test for duplicates
            for (d=0;d<100;d++)
            {
                if (myNum == numArray[i][d])
                {
                    //this if statement is required to avoid comparing the number to its own self (without this,
                    //every entry would consider its own self a duplicate
                    if (d == j)
                    {
                        continue;
                    }

                    //print the duplicate
                    printf("%d ",myNum);
                }
            }


        }


        printf("\n");

    }

    //for testing purposes, here is the original list

    for (i=0; i<10; i++)
    {
        printf("Row %d :\n",i);
        for (j=0;j<100;j++)
        {
            printf("%d\t",numArray[i][j]);
        }
        printf("\n");
    }


}
