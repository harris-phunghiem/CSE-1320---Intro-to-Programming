/*Made by Harris Nghiem
CSE 1320
Homework 4 - Task 2*/

#include <stdio.h>
#include <stdlib.h>     //for atoi

int main ()
{
  int i;    //generic iterator
  int firstNumFlag = 1;     //this will be used for the first input so that the program knows to treat the first number as the initial max/min
  int dupFlag = 0;          //this flag will allow the program to determine what to do depending on whether a number was deemed a duplicate or not
  int filledIndex = 0;      //this determines how "filled" the array will be when checking for duplicates.  That is, if only four numbers exist in
                            //the array, then the program must stop at that point, as checking the fifth element or beyond will lead to false results
                            //and potentially even crashes.
  int numArray[1000];       //the actual array that is used to store accepted values and to check against duplicates
  char buffer[1000];        //simple buffer for input
  int myInteger;            //the user's input
  int myMin = 0;            //the current minimum value
  int myMax = 0;            //the current maximum value


    //a simple 'reset' loop to make the array equal zero.  We want to minimize the risk of false data at the cost of a little performance
  for (i = 0; i< 1000; i++)
  {
      numArray[i]=0;
  }

    //infinite loop for getting input
  while(1)
  {

    printf ("Please enter a unique number.  If you wish to exit, please enter X for exit.\n");

    fgets (buffer, 100, stdin);

    //we need a method to allow the loop to exit; the easiest way is to accept a specific non-integer such as X as the input
    if (*buffer == 'x' || i == 'X')
    {
        break;
        //breaks outside of the while loop
    }

    //if myInteger does not equal x, then it is assumed that the user typed an integer; this converts the char to an int
    myInteger = atoi (buffer);

    //this flag is necessary so that the program knows to initialize the max and min as the first valid input number
    if (firstNumFlag == 1)
    {
        myMin = myInteger;
        myMax = myInteger;

    }


    //Because the array is initialized to 0, there needs to be a special case reserved for letting the program
    //know whether a zero that it encounters is a 'true' zero given by the user, or whether it's just a default
    //zero denoting that the array is empty.  Unfortunately, we have to assume ANY integer (including a zero or
    //or negative) is a valid input, so this section will take care of that issue.

    //if the user puts in a zero
    if (myInteger == 0)
    {


        for (i = 0; i<= filledIndex; i++)
        {
            //if the very first input is a zero, then we immediately tell the program to manually move the index forward by one
            //and to immediately ask the user for the next input via a double break (this break leads to a continue within this if
            //loop
            if (filledIndex == 0)
            {
                filledIndex++;
                break;  //leads to continue
            }

            //if we reach the first unoccupied spot, we change it zero (just to be safe) and then move the filledIndex forward by one
            else if (i == filledIndex)
            {
                numArray[filledIndex]=0;
                filledIndex++;
                break;  //leads to continue
            }

            //if we encounter a zero anywhere else (that is, aside from the two special cases above), THEN we can safely assume it's a duplicate
            else if (numArray[i]==0)
            {
                printf("--> That is a duplicate.  Try again.\n");
                break;  //leads to continue
            }



        }

        //turn off the "empty list flag"
        firstNumFlag=0;

        continue;  //leads to the while(1)
    }

    //The main function for checking for duplicates and appending to numArray
    for (i=0; i<=filledIndex; i++)
    {

        //this is to check whether we had any numbers put in (in case of empty list)
        if (firstNumFlag)
        {
            firstNumFlag = 0;
        }

        //if the input number equals a number already put in:
        if (numArray[i] == myInteger)
        {
            //tell user it's a duplicate
            printf("--> This is a duplicate (or not a valid input)!  Try again!\n");
            //set off a flag denoting a duplicate
            dupFlag = 1;
            //break to "if (dupFlag == 0)"
            break;
        }
    }

    //if the number was not a dupe
    if (dupFlag == 0)
    {

        //check for new max
        if (myInteger > myMax)
        {
            myMax = myInteger;
        }
        //check for new min
        if (myInteger < myMin)
        {
            myMin = myInteger;
        }
        //replace the newest value in the array with the input
        numArray[filledIndex] = myInteger;
        filledIndex++;
    }

    //set the duplicate to false since a new number is going to be tested
    dupFlag = 0;
  }

  printf("*********************************************\n");

  //if this flag was never turned off, it means no value was accepted; the list is empty
  if (firstNumFlag == 1)
    {
        printf("You did not enter any numbers, so there is no maximum or minimum. Nice attempt at tricking me, though! \n");
    }

  else
  {

    printf("Disregarding duplicates, your numbers (in the order they were typed) were: \n\n");

    for (i=0;i<filledIndex;i++)
    {
      printf("%d\n",numArray[i]);
    }

    printf("MAXIMUM: %d\nMINIMUM: %d\n",myMax,myMin);
  }


}
