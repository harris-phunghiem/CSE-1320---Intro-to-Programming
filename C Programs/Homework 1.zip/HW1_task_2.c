/*
* Task 2
* Written by Harris Nghiem
* January 27th, 2015
* CSE 1320 - Intermediate Programming
*/

int main()
{
    printf ("%09d", 1);
    printf("%9.10s", "00000000010000000000");
    printf ("%09d", 1);
    printf ("%09d\n", 000000000);
    printf("%37s\n", "000000000");
    printf ("%09d\n", 1);
    printf ("%09d%28s", 1,"000000000");
    return 0;

}
